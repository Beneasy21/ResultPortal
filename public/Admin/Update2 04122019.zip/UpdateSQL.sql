UPDATE students SET house = "1" WHERE house = "Dragon";
UPDATE students SET house = "2" WHERE house = "Hippopotamus";
UPDATE students SET house = "3" WHERE house = "Rhinoceros";
UPDATE students SET house = "4" WHERE house = "Stallion";
UPDATE students SET house = "5" WHERE house = "Tiger";
UPDATE students SET house = "6" WHERE house = "Commandant";
